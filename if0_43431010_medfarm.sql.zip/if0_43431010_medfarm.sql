-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql102.infinityfree.com
-- Generation Time: Nov 18, 2026 at 04:09 PM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43431010_medfarm`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sender` enum('user','seller') NOT NULL DEFAULT 'user',
  `message` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `type` enum('percent','fixed') NOT NULL DEFAULT 'percent',
  `value` decimal(10,2) NOT NULL,
  `min_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `max_discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `code`, `type`, `value`, `min_total`, `max_discount`, `is_active`) VALUES
(1, 'SALE10', 'percent', '10.00', '1000.00', '500.00', 1),
(2, 'FIX500', 'fixed', '500.00', '2000.00', '0.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `excluded_urls`
--

CREATE TABLE `excluded_urls` (
  `id` int(10) UNSIGNED NOT NULL,
  `url` varchar(255) NOT NULL,
  `reason` enum('robots','noindex','404','duplicate','soft404','other') NOT NULL,
  `action_taken` varchar(255) DEFAULT NULL,
  `status` enum('new','in_progress','fixed','ignored') NOT NULL DEFAULT 'new',
  `checked_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `excluded_urls`
--

INSERT INTO `excluded_urls` (`id`, `url`, `reason`, `action_taken`, `status`, `checked_at`) VALUES
(1, 'site/admin/', 'robots', 'Оставлено закрытым', 'fixed', '2026-11-13 13:34:39'),
(2, 'site/login.php', 'noindex', 'Добавлен noindex', 'fixed', '2026-11-13 13:34:39'),
(3, 'site/product.php?id=15', '404', 'Ссылка удалена', 'fixed', '2026-11-13 13:34:39'),
(4, 'site/catalog.php?page=1', 'duplicate', 'Добавлен canonical', 'in_progress', '2026-11-13 13:34:39'),
(5, '/admin/index.php', 'robots', 'Оставить, это служебная папка', 'fixed', '2026-11-14 00:02:22'),
(6, '/product.php?id=15', 'duplicate', 'Настроить 301-редирект', 'in_progress', '2026-11-14 00:02:22'),
(7, '/product.php?id=8', 'soft404', 'Добавить описание в БД', 'new', '2026-11-14 00:02:22'),
(8, '/admin/index.php', 'robots', 'Оставить, это служебная папка', 'fixed', '2026-11-14 00:02:24'),
(9, '/product.php?id=15', 'duplicate', 'Настроить 301-редирект', 'in_progress', '2026-11-14 00:02:24'),
(10, '/product.php?id=8', 'soft404', 'Добавить описание в БД', 'new', '2026-11-14 00:02:24');

-- --------------------------------------------------------

--
-- Table structure for table `indexing_snapshots`
--

CREATE TABLE `indexing_snapshots` (
  `id` int(10) UNSIGNED NOT NULL,
  `snapshot_date` date NOT NULL,
  `source` enum('yandex','google') NOT NULL,
  `total_urls` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `indexed` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `excluded` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `notes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `indexing_snapshots`
--

INSERT INTO `indexing_snapshots` (`id`, `snapshot_date`, `source`, `total_urls`, `indexed`, `excluded`, `notes`) VALUES
(1, '2026-11-01', 'yandex', 60, 15, 45, NULL),
(2, '2026-11-08', 'yandex', 60, 25, 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('new','paid','shipped','delivered','cancelled') NOT NULL DEFAULT 'new',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total`, `status`, `created_at`) VALUES
(1, 1, '1250.00', 'paid', '2026-11-13 13:34:39'),
(2, 2, '0.00', 'paid', '2026-11-17 14:18:22');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `price`, `qty`) VALUES
(1, 1, 1, '85.00', 2),
(2, 1, 2, '120.00', 9),
(3, 2, 1, '0.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` enum('Лекарства','Витамины и БАД','Гигиена') NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `image_alt` varchar(255) DEFAULT NULL,
  `image_webp` varchar(500) DEFAULT NULL,
  `image_width` smallint(5) UNSIGNED DEFAULT NULL,
  `image_height` smallint(5) UNSIGNED DEFAULT NULL,
  `image_title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT 0.0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `price`, `image`, `image_alt`, `image_webp`, `image_width`, `image_height`, `image_title`, `description`, `rating`, `created_at`) VALUES
(1, 'Парацетамол 500мг №20Супермегадлинноеназваниебезпробелов20Супермегадлинноеназваниебезпробелов', 'Лекарства', '85.00', 'img/paracetamol.webp', 'Парацетамол упаковка', 'img/paracetamol.webp', NULL, NULL, NULL, 'Жаропонижающее.', '5.0', '2026-11-13 21:34:39'),
(2, 'Ибупрофен 200мг №20', 'Лекарства', '120.00', 'img/ibuprofen.webp', 'Ибупрофен упаковка', 'img/ibuprofen.webp', NULL, NULL, NULL, 'НПВС.', '0.0', '2026-11-13 21:34:39'),
(3, 'Аспирин 100мг №30', 'Лекарства', '95.00', 'img/aspirin.webp', 'Аспирин упаковка', 'img/aspirin.webp', NULL, NULL, NULL, 'Разжижает кровь.', '0.0', '2026-11-13 21:34:39'),
(4, 'Амоксициллин 500мг №16', 'Лекарства', '210.00', 'img/amoksic.png', 'Амоксициллин упаковка', 'img/amoksic.png', NULL, NULL, NULL, 'Антибиотик.', '0.0', '2026-11-13 21:34:39'),
(5, 'Омепразол 20мг №28', 'Лекарства', '175.00', 'img/omeprazol.webp', 'Омепразол упаковка', 'img/omeprazol.webp', NULL, NULL, NULL, 'При гастрите.', '0.0', '2026-11-13 21:34:39'),
(6, 'Витамин C 1000мг №60', 'Витамины и БАД', '350.00', 'img/vitc.webp', 'Витамин С', 'img/vitc.webp', NULL, NULL, NULL, 'Для иммунитета.', '0.0', '2026-11-13 21:34:39'),
(7, 'Витамин D3 2000МЕ №90', 'Витамины и БАД', '490.00', 'img/vitd.webp', 'Витамин D3', 'img/vitd.webp', NULL, NULL, NULL, 'Для костей.', '0.0', '2026-11-13 21:34:39'),
(8, 'Омега-3 1000мг №60', 'Витамины и БАД', '680.00', 'img/omega.webp', 'Омега-3', 'img/omega.webp', NULL, NULL, NULL, 'Для сердца.', '0.0', '2026-11-13 21:34:39'),
(9, 'Магний B6 №50', 'Витамины и БАД', '420.00', 'img/magniy.webp', 'Магний B6', 'img/magniy.webp', NULL, NULL, NULL, 'При стрессе.', '0.0', '2026-11-13 21:34:39'),
(10, 'Цинк 25мг №60', 'Витамины и БАД', '320.00', 'img/zinc.webp', 'Цинк', 'img/zinc.webp', NULL, NULL, NULL, 'Для кожи.', '0.0', '2026-11-13 21:34:39'),
(11, 'Зубная паста Colgate 100мл', 'Гигиена', '180.00', 'img/colgate.webp', 'Зубная паста', 'img/colgate.webp', NULL, NULL, NULL, 'Защита от кариеса.', '0.0', '2026-11-13 21:34:39'),
(12, 'Зубная щётка Soft', 'Гигиена', '120.00', 'img/brush.webp', 'Зубная щетка', 'img/brush.webp', NULL, NULL, NULL, 'Мягкая щетина.', '0.0', '2026-11-13 21:34:39'),
(13, 'Ополаскиватель 500мл', 'Гигиена', '220.00', 'img/rinse.webp', 'Ополаскиватель', 'img/rinse.webp', NULL, NULL, NULL, 'Свежее дыхание.', '0.0', '2026-11-13 21:34:39'),
(14, 'Мыло антибактериальное 90г', 'Гигиена', '65.00', 'img/soap.webp', 'Мыло', 'img/soap.webp', NULL, NULL, NULL, 'Убивает 99% бактерий.', '0.0', '2026-11-13 21:34:39'),
(15, 'Гель для душа 250мл', 'Гигиена', '190.00', 'img/gel.webp', 'Гель для душа', 'img/gel.webp', NULL, NULL, NULL, 'С лавандой.', '0.0', '2026-11-13 21:34:39');

-- --------------------------------------------------------

--
-- Table structure for table `promotions`
--

CREATE TABLE `promotions` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `type` enum('day','week','month') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `discount` tinyint(4) NOT NULL DEFAULT 0,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL
) ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `rating`, `text`, `created_at`) VALUES
(1, 1, 1, 5, 'Отличное средство, помогло за 1 день.', '2026-11-13 21:34:39'),
(2, 1, 2, 5, 'очень хорошее лекство, прям ооооооооочень. всем советую, покупайте, пожалуйстаffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', '2026-11-17 22:38:43');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `key` varchar(64) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`key`, `value`) VALUES
('site_logo', 'img/logo.svg'),
('site_logo_alt', 'Логотип онлайн-аптеки МедФарм'),
('site_name', 'МедФарм');

-- --------------------------------------------------------

--
-- Table structure for table `url_checks`
--

CREATE TABLE `url_checks` (
  `id` int(10) UNSIGNED NOT NULL,
  `url` varchar(255) NOT NULL,
  `http_code` smallint(5) UNSIGNED NOT NULL,
  `has_noindex` tinyint(1) NOT NULL DEFAULT 0,
  `canonical` varchar(255) DEFAULT NULL,
  `checked_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `url_checks`
--

INSERT INTO `url_checks` (`id`, `url`, `http_code`, `has_noindex`, `canonical`, `checked_at`) VALUES
(1, 'site/index.php', 200, 0, 'site/index.php', '2026-11-13 13:34:39'),
(2, 'site/catalog.php', 200, 0, 'site/catalog.php', '2026-11-13 13:34:39'),
(3, 'site/product.php?id=1', 200, 0, 'site/product.php?id=1', '2026-11-13 13:34:39'),
(4, 'site/admin/admin.php', 200, 1, NULL, '2026-11-13 13:34:39');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `is_admin`, `created_at`) VALUES
(1, 'Иван Петров', 'ivan@medfarm.ru', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1Hd5mHk6Yy3uF3uX5rL4pQ8mX0nZq9K', 1, '2026-11-13 21:34:39'),
(2, 'кар', 'test@mail.ru', '$2y$12$DiUJqzaHpjS2kxif3OWR6.U/saLOKX.GIcnqnmmSuWXTeruGBioxq', 0, '2026-11-17 20:54:06');

-- --------------------------------------------------------

--
-- Table structure for table `vk_ads_ads`
--

CREATE TABLE `vk_ads_ads` (
  `id` int(10) UNSIGNED NOT NULL,
  `campaign_id` int(10) UNSIGNED NOT NULL,
  `ad_group` varchar(64) NOT NULL,
  `creative` varchar(64) NOT NULL,
  `status` enum('moderation','active','rejected','paused') NOT NULL DEFAULT 'moderation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vk_ads_ads`
--

INSERT INTO `vk_ads_ads` (`id`, `campaign_id`, `ad_group`, `creative`, `status`) VALUES
(1, 1, 'Интересы', 'A_Скидка', 'active'),
(2, 1, 'Интересы', 'B_Гарантия', 'active'),
(3, 1, 'Ретаргетинг', 'C_Ассортимент', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `vk_ads_campaigns`
--

CREATE TABLE `vk_ads_campaigns` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) NOT NULL,
  `objective` enum('traffic','conversions','messages') NOT NULL,
  `daily_budget` decimal(10,2) NOT NULL,
  `status` enum('draft','active','paused','archived') NOT NULL DEFAULT 'draft'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vk_ads_campaigns`
--

INSERT INTO `vk_ads_campaigns` (`id`, `name`, `objective`, `daily_budget`, `status`) VALUES
(1, 'МедФарм_Октябрь', 'conversions', '1000.00', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `vk_ads_daily`
--

CREATE TABLE `vk_ads_daily` (
  `id` int(10) UNSIGNED NOT NULL,
  `ad_id` int(10) UNSIGNED NOT NULL,
  `stat_date` date NOT NULL,
  `impressions` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `clicks` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `spend` decimal(10,2) NOT NULL DEFAULT 0.00,
  `conversions` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `revenue` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `excluded_urls`
--
ALTER TABLE `excluded_urls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `indexing_snapshots`
--
ALTER TABLE `indexing_snapshots`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_snapshot` (`snapshot_date`,`source`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `promotions`
--
ALTER TABLE `promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `url_checks`
--
ALTER TABLE `url_checks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vk_ads_ads`
--
ALTER TABLE `vk_ads_ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vk_ads_campaigns`
--
ALTER TABLE `vk_ads_campaigns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vk_ads_daily`
--
ALTER TABLE `vk_ads_daily`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_wish` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `excluded_urls`
--
ALTER TABLE `excluded_urls`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `indexing_snapshots`
--
ALTER TABLE `indexing_snapshots`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `promotions`
--
ALTER TABLE `promotions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `url_checks`
--
ALTER TABLE `url_checks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vk_ads_ads`
--
ALTER TABLE `vk_ads_ads`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vk_ads_campaigns`
--
ALTER TABLE `vk_ads_campaigns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vk_ads_daily`
--
ALTER TABLE `vk_ads_daily`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `promotions`
--
ALTER TABLE `promotions`
  ADD CONSTRAINT `promotions_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
